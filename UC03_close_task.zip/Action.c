Action()
{

	char  *VtsServer = "192.168.2.117";
	int   nPort = 8888;
	int   rc;
	rc = lrvtc_connect(VtsServer,nPort,VTOPT_KEEP_ALIVE);
    lr_log_message("Connect result rc=%d\n", rc);

//   

	rc = lrvtc_retrieve_message("ID_E");
    lr_log_message("Retrieve_message rc=%d\n", rc);
    lr_log_message("Retrieved value is: %s", lr_eval_string("{ID_E}"));

	web_add_cookie("filterSetting="
		"%7B%22page%22%3A%22http%3A%2F%2F192.168.14.54%3A9433%2F%23tickets%3Fstate%3Dopened%26page%3D1%22%2C%22smho%22%3Anull%2C%22dateStart%22%3A%22%22%2C%22dateEnd%22%3A%22%22%2C%22cat1%22%3Anull%2C%22cat2%22%3Anull%2C%22cat3%22%3Anull%2C%22cat4%22%3Anull%2C%22theme%22%3Anull%2C%22engineer%22%3Anull%2C%22location%22%3Anull%2C%22division%22%3Anull%2C%22overdue%22%3Afalse%2C%22filters%22%3A%7B%22newCheckbox%22%3Afalse%2C%22appointedCheckbox%22%3Afalse%2C%22performedCheckbox%22%3Atrue%2C%22controlCheckbox%2"
		"2%3Afalse%7D%7D; DOMAIN=192.168.14.54");

/*	web_add_auto_header("DNT", 
		"1");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest"); */

	lr_think_time(3);
	
	web_reg_save_param_json(
        "ParamName=JSON_task_id",
        "QueryString=$.content.[*].taskId",
        "SelectAll=yes",
        SEARCH_FILTERS,
        "Scope=Body",
       LAST);
	
	lr_start_transaction("UC03_01_filter");
	web_custom_request("ticket_2", 
		"URL=http://192.168.14.54:9433/api/ticket/?state=1&page=0&size=10", 
		"Method=GET", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
/*		EXTRARES, 
		"Url=/engineer/ticket/ticket.dust", "Referer=http://192.168.14.54:9433/", ENDITEM, 
		"Url=/engineer/ticket/ticket.js", "Referer=http://192.168.14.54:9433/", ENDITEM, 
		"Url=/images/logo-5ka.png", "Referer=http://192.168.14.54:9433/", ENDITEM, */
		LAST);
	lr_end_transaction("UC03_01_filter",LR_AUTO);
	
	lr_save_string(lr_paramarr_random("JSON_task_id"),"random_task_id");
	
	lr_start_transaction("UC03_02_click_task");
	web_custom_request("160186", 
		"URL=http://192.168.14.54:9433/api/ticket/{ID_E}", 
		"Method=GET", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
/*		EXTRARES, 
		"Url=/images/custom.png", "Referer=http://192.168.14.54:9433/", ENDITEM, 
		"Url=/tpl/comment.dust", "Referer=http://192.168.14.54:9433/", ENDITEM, */
		LAST);

	web_url("comment", 
		"URL=http://192.168.14.54:9433/api/ticket/{ID_E}/comment/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		LAST);

	lr_start_transaction("UC03_03_close_incident_click");
	web_custom_request("solve", 
		"URL=http://192.168.14.54:9433/api/ticket/{ID_E}/solve/", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);
	lr_end_transaction("UC03_03_close_incident_click",LR_AUTO);
	lr_think_time(3);
	lr_start_transaction("UC03_04_click_ok");

/*	web_revert_auto_header("X-Requested-With");

	web_add_header("Upgrade-Insecure-Requests", 
		"1"); */
	web_url("192.168.14.54:9433_2", 
		"URL=http://192.168.14.54:9433/", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
/*		EXTRARES, 
		"Url=/js/core/jqueryformplugin.js?_=1583755524319", ENDITEM, 
		"Url=/engineer/wrapper/wrapper.dust", ENDITEM, 
		"Url=/engineer/wrapper/wrapper.js", ENDITEM, 
		"Url=/engineer/tickets/tickets.dust", ENDITEM, 
		"Url=/engineer/tickets/tickets.js", ENDITEM, */
		LAST);

/*	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest"); */

	web_url("checkLogin_2", 
		"URL=http://192.168.14.54:9433/api/checkLogin", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		LAST);

	web_url("info_2", 
		"URL=http://192.168.14.54:9433/api/user/info", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t16.inf", 
		"Mode=HTML", 
		LAST);

	web_url("4_2", 
		"URL=http://192.168.14.54:9433/api/ticket/countByState/4", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t17.inf", 
		"Mode=HTML", 
		LAST);

	web_url("countByState_2", 
		"URL=http://192.168.14.54:9433/api/ticket/countByState/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t18.inf", 
		"Mode=HTML", 
		LAST);

	web_url("countByState_3", 
		"URL=http://192.168.14.54:9433/api/ticket/countByState/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t19.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("ticket_3", 
		"URL=http://192.168.14.54:9433/api/ticket/?state=-1,0,1,5&page=0&size=10", 
		"Method=GET", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t20.inf", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		LAST);
	lr_end_transaction("UC03_04_click_ok",LR_AUTO);
	
	web_custom_request("ticket_3", 
		"URL=http://192.168.14.54:9433/api/ticket/?state=-1,0,1,5&page=0&size=10", 
		"Method=GET", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t20.inf", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		LAST);
	lr_end_transaction("UC03_02_click_task",LR_AUTO);
//	lr_log_message(lr_eval_string("{ID_E}"));
	rc = lrvtc_disconnect();
	return 0;
}

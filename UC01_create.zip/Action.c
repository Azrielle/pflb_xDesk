Action()
{
	int i,j,array_len,random_idx,error_chek;
	
	
	
	char  *VtsServer = "192.168.2.117";
	int   nPort = 8888;
	int   rc;



	lr_think_time(3);
	lr_start_transaction("UC01_01_click_new_incident");

/*	web_add_cookie("filterSetting="
		"%7B%22page%22%3A%22http%3A%2F%2F192.168.14.54%3A9433%2F%23tickets%3Fstate%3Dopened%26page%3D1%22%2C%22smho%22%3Anull%2C%22dateStart%22%3A%22%22%2C%22dateEnd%22%3A%22%22%2C%22cat1%22%3Anull%2C%22cat2%22%3Anull%2C%22cat3%22%3Anull%2C%22cat4%22%3Anull%2C%22theme%22%3Anull%2C%22engineer%22%3Anull%2C%22location%22%3Anull%2C%22division%22%3Anull%2C%22overdue%22%3Afalse%2C%22filters%22%3A%7B%22newCheckbox%22%3Atrue%2C%22appointedCheckbox%22%3Atrue%2C%22performedCheckbox%22%3Atrue%2C%22controlCheckbox%22%"
		"3Atrue%7D%7D; DOMAIN=192.168.14.54");

	web_add_auto_header("DNT", 
		"1");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest"); */

	
	web_url("children", 
		"URL=http://192.168.14.54:9433/api/user/catalog/node/0/children/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
/*		EXTRARES, 
		"Url=/images/logo-5ka.png", "Referer=http://192.168.14.54:9433/", ENDITEM, */
		LAST);

	lr_think_time(3);

	lr_start_transaction("UC01_02_select_adres");
	web_reg_save_param_json(
        "ParamName=JSON_location_adress",
        "QueryString=$..location",
        "SelectAll=yes",
        SEARCH_FILTERS,
        "Scope=Body",
       LAST);
	web_reg_save_param_json(
        "ParamName=JSON_id_adress",
        "QueryString=$..id",
        "SelectAll=yes",
        SEARCH_FILTERS,
        "Scope=Body",
       LAST);
	web_url("get_JSON_id_adress", 
		"URL=http://192.168.14.54:9433/api/shops?q=&page=0", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		LAST);

	lr_think_time(3);

	web_url("children_2", 
		"URL=http://192.168.14.54:9433/api/user/catalog/node/0/children/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		LAST);
	
	lr_save_string(lr_paramarr_random("JSON_id_adress"),"random_id_adress");
	web_reg_save_param_json(
        "ParamName=JSON_service_id",
        "QueryString=$..services..id",
        "SelectAll=yes",
        SEARCH_FILTERS,
        "Scope=Body",
       LAST);
       web_reg_save_param_json(
        "ParamName=JSON_service_parent_id",
        "QueryString=$..services..parentId",
        "SelectAll=yes",
        SEARCH_FILTERS,
        "Scope=Body",
       LAST);
	web_reg_save_param_json(
        "ParamName=JSON_service_name",
        "QueryString=$..services..name",
        "SelectAll=yes",
        SEARCH_FILTERS,
        "Scope=Body",
       LAST);
	web_reg_save_param_json(
        "ParamName=JSON_service_parent_name",
        "QueryString=$..services..parentName",
        "SelectAll=yes",
        SEARCH_FILTERS,
        "Scope=Body",
       LAST);
	web_url("get_JSON_service", 
		"URL=http://192.168.14.54:9433/api/user/catalog/treeview?shopid={random_id_adress}", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
/*		EXTRARES, 
		"Url=/engineer/catalog/catalog.dust", "Referer=http://192.168.14.54:9433/", ENDITEM, 
		"Url=/engineer/catalog/catalog.js", "Referer=http://192.168.14.54:9433/", ENDITEM, */
		LAST);

	lr_end_transaction("UC01_02_select_adres",LR_AUTO);

	lr_start_transaction("UC01_03_select_tema");

	web_url("children_3", 
		"URL=http://192.168.14.54:9433/api/user/catalog/node/146/children/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		LAST);

	web_url("service", 
		"URL=http://192.168.14.54:9433/api/user/catalog/node/146/service/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t16.inf", 
		"Mode=HTML", 
		LAST);

	web_url("146", 
		"URL=http://192.168.14.54:9433/api/user/catalog/breadcrumbs/146", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t17.inf", 
		"Mode=HTML", 
/*		EXTRARES, 
		"Url=/engineer/addticket.dust", "Referer=http://192.168.14.54:9433/", ENDITEM, */
		LAST);

	random_idx=rand()%lr_paramarr_len("JSON_service_id")+1;
	lr_save_string(lr_paramarr_idx("JSON_service_id",random_idx),"random_service_id");
	lr_save_string(lr_paramarr_idx("JSON_service_parent_id",random_idx),"parent_id_for_service_id");
	lr_save_string(lr_paramarr_idx("JSON_service_name",random_idx),"service_id_name");
	lr_save_string(lr_paramarr_idx("JSON_service_parent_name",random_idx),"service_id_parent_name");
		
	web_reg_save_param_json(
        "ParamName=JSON_inventory_numbers_id",
        "QueryString=$..id",
        "SelectAll=yes",
        "Notfound=warning",
        SEARCH_FILTERS,
        "Scope=Body",
       LAST);
	web_url("get_JSON_inventory_numbers_id", 
		"URL=http://192.168.14.54:9433/api/inventoryNumbers?serviceId={random_service_id}&shopId={random_id_adress}", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t18.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("UC01_03_select_tema",LR_AUTO);

	lr_think_time(3);

	lr_start_transaction("UC01_03_click_create");
	if (lr_paramarr_len("JSON_inventory_numbers_id")==0){
		lr_save_string("null","random_inventory_numbers_id_or_null");
	}else{
		lr_save_string(lr_paramarr_random("JSON_inventory_numbers_id"),"random_inventory_numbers_id_or_null");
	}
	web_reg_save_param_json(
        "ParamName=JSON_id_n",
        "QueryString=$.id",
        "Notfound=warning",
        SEARCH_FILTERS,
        "Scope=Body",
       LAST);
	web_custom_request("ticket_2", 
		"URL=http://192.168.14.54:9433/api/ticket/", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t19.inf", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		"BodyBinary={\"text\":\"{service_id_parent_name}\",\"header\":\"{service_id_name}\",\"ticketStateId\":0,\"serviceId\":\"{random_service_id}\",\"files\":[],\"inventoryNumberId\":\"{random_inventory_numbers_id_or_null}\",\"shopId\":\"{random_id_adress}\"}",
		LAST);

	lr_end_transaction("UC01_03_click_create",LR_AUTO);

	lr_start_transaction("UC01_05_click_ok");

/*	web_revert_auto_header("X-Requested-With");

	web_add_header("Upgrade-Insecure-Requests", 
		"1"); */

	lr_think_time(3);

	web_url("192.168.14.54:9433_2", 
		"URL=http://192.168.14.54:9433/", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t20.inf", 
		"Mode=HTML", 
/*		EXTRARES, 
		"Url=/js/core/jqueryformplugin.js?_=1583758456543", ENDITEM, 
		"Url=/engineer/wrapper/wrapper.dust", ENDITEM, 
		"Url=/engineer/wrapper/wrapper.js", ENDITEM, 
		"Url=/engineer/tickets/tickets.dust", ENDITEM, 
		"Url=/engineer/tickets/tickets.js", ENDITEM, */
		LAST);

/*	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest"); */

	web_url("checkLogin_2", 
		"URL=http://192.168.14.54:9433/api/checkLogin", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t21.inf", 
		"Mode=HTML", 
		LAST);

	web_url("info_2", 
		"URL=http://192.168.14.54:9433/api/user/info", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t22.inf", 
		"Mode=HTML", 
		LAST);

	web_url("4_2", 
		"URL=http://192.168.14.54:9433/api/ticket/countByState/4", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t23.inf", 
		"Mode=HTML", 
		LAST);

	web_url("countByState_2", 
		"URL=http://192.168.14.54:9433/api/ticket/countByState/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t24.inf", 
		"Mode=HTML", 
		LAST);

	web_url("countByState_3", 
		"URL=http://192.168.14.54:9433/api/ticket/countByState/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t25.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("ticket_3", 
		"URL=http://192.168.14.54:9433/api/ticket/?state=-1,0,1,5&page=0&size=10", 
		"Method=GET", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t26.inf", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		LAST);

	web_custom_request("ticket_4", 
		"URL=http://192.168.14.54:9433/api/ticket/?state=-1,0,1,5&page=0&size=10", 
		"Method=GET", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t27.inf", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		LAST);

	lr_end_transaction("UC01_05_click_ok",LR_AUTO);

	lr_end_transaction("UC01_01_click_new_incident",LR_AUTO);
	

	rc = lrvtc_connect(VtsServer,nPort,VTOPT_KEEP_ALIVE);
    lr_log_message("Connect result rc=%d\n", rc);

    rc = lrvtc_send_row1("ID_N", 
        "{JSON_id_n}", ";", 
        VTSEND_SAME_ROW);
	lr_log_message("send_row1 rc=%d\n", rc);
    rc = lrvtc_disconnect();
    lr_log_message("Disconnect result rc=%d\n", rc);
	return 0;
}

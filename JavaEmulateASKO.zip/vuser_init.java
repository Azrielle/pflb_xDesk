//import lrapi.lr;
//import lrapi.vts.Lrvtc;
//import lrapi.vts.Constants;
//
//
//public class Actions {
//    private static final String VtsServer = "192.168.2.117";
//    private static final int nPort = 8888;
//    private static int rc = 0;
//    public int init() throws Throwable {
//        rc = Lrvtc.connect(VtsServer, nPort, Constants.VTOPT_KEEP_ALIVE);
//        lr.log_message("rc=" + rc + "\n");
//        return 0;
//    }// end of init

// Do not change this file

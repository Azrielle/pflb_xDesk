/*
 * LoadRunner Java script. (Build: _build_number_)
 * 
 * Script Description: 
 *                     
 */
import lrapi.lr;
import java.sql.*;
import lrapi.vts.Lrvtc;
import lrapi.vts.Constants;


public class Actions
{

	public int init() throws Throwable {
		String VtsServer = "192.168.2.117";
	    int nPort = 8888;
	    int rc_vts = 0;
	    rc_vts = Lrvtc.connect(VtsServer, nPort, Constants.VTOPT_KEEP_ALIVE);
		return 0;
	}//end of init


	public int action() throws Throwable {
		
		int rc_vts = 0;
	    lr.log_message("rc=" + "{ID_N}" + "\n");

	    

		rc_vts = Lrvtc.retrieve_message("ID_N");
      	lr.log_message("retrieve_message rc=" + rc_vts + "\n");
      	lr.log_message("retrieve_message rc=" + lr.eval_string("{ID_N}") + "\n");
      	Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@192.168.14.53:1522:orcl","c##x5","c##x5");
		if (conn != null)
		{
			System.out.println("Connected to db");
			String query = "Update ticket set state_id=1 where id="+lr.eval_string("{ID_N}");
			int id_ticket;
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(query);
			query = "insert into task (id,ticket_id,state_id,client_id,guid,header,text,create_date,external_system)"+
				"select id,id,state_id,'106',guid,header,text,create_date,'ASKO' from ticket where id="+lr.eval_string("{ID_N}");
			rs = stmt.executeQuery(query);	
		}
		else
		{
			System.out.println("Failed connected to db");
		}
		
		conn.close();
		rc_vts = Lrvtc.send_message("ID_E", lr.eval_string("{ID_N}"));
        lr.log_message("send_message rc=" + rc_vts + "\n");

        return 0;
	}//end of action


	public int end() throws Throwable {
		Lrvtc.disconnect();
		return 0;
	}//end of end
}


